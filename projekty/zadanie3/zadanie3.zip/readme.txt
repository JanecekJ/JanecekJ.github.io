Obsah archívu
-------------
/html_prezentacia
	- adresár obsahujúci vygenerované html slidy prezentácie a CSS stylesheet

/obrazky
	- adresár obsahujúci obrázky použité v xml prezentácií

basic.xsl
	- stylesheet so základnými transformáciami

html.xsl
	- stylesheet s transformáciami pre html

pdf.xsl
	- stylesheet s transformáciami pre pdf

html.bat
	- bat súbor na vygenerovanie html prezentácie

pdf.bat
	- bat súbor na vygenerovanie pdf prezentácie

prezentácia.xml
	- prezentácia vo formáte xml

prezentácia.xsd
	- definícia obsahu xml prezentácie

prezentacia.fo
	- vygenrovaný fo súbor

prezentacia.pdf
	- vygenerovaná pdf prezentácia

Spustenie transformácií
-----------------------
- Na vykoananie transfromácií je nutné mať dostupnú Saxon knižnicu na adrese C:\Saxon\saxon9he.jar 

- Pre transformáciu do pdf je taktiež nutné mať dostupný DocBook na adrese C:\DocBook\xep\xep.bat

- Ak sú tieto knižnice dostupné na inej adrese v systéme, je nutné upraviť bat súbory tak aby zodpovedali týmto adresám

1. Rozbaliť celý archív do nejaké adresára
2. Otvoriť príkazový riadok v danom adresári
3. Pre pdf prezentáciu zadať príkaz "pdf.bat"
4. Pre html prezentáciu zadať príkaz "html.bat"

- Ak sa pri týchto príkazoch nezadá žiaden argument, je automaticky zapnuté číslovanie slidov a font je nastavený na Arial

- Je možné zadať argument "cislovanie-0", ktorý vypne číslovanie slidov a argument "font-times", ktorý nastaví font na Times new roman